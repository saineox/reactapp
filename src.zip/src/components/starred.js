import React from "react";

const StarredPage = () => {
  return(
    <div className="main">
      <h1>Starred Page is loaded</h1>
    </div>
  )
}

export default StarredPage;