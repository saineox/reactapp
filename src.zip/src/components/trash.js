import React from "react";

const TrashPage = () => {

    return (
        <div className="main">
            <h3> TrashPage </h3>
        </div>
    )
}

export default TrashPage;