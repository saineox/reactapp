import React from "react";

const SentPage = () => {

    return (
        <div className="main">
            <h3> SentPage </h3>
        </div>
    )
}

export default SentPage;